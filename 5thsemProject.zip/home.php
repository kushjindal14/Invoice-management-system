<?php include 'connect.php'; 
    if(isset($_SESSION['id'])){  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HOME</title>
    <style>
        #companydetails{
            margin: 50px 50px ;
        }
    </style>
    <script defer src="all.min.js"></script>  
    <link rel="stylesheet" href="style.min.css">
    <link rel="stylesheet" href="hom.css">
</head>
<body>
	<div class="topline">
        <a href="home.php" class="brand">SSDPP</a>
        <a href="phpscripts.php?logout=1">LOGOUT</a>
    </div>
    <div class="contents">
        <div class="varticalnav">
            <a href="home.php" id="active"><i class="fas fa-home"></i> Home</a><b><br><br><br><br></b>
            <a href="products.php"><i class="fab fa-product-hunt"></i></i> Products</a>
            <a href="invoice.php"><i class="fas fa-file-invoice"></i> Invoice</a>
            <a href="client.php"><i class="far fa-user"></i> Clients</a>
            <a href="estimate.php"><i class="far fa-file-alt"></i> Estimate</a>
            <a href="payment.php"><i class="fas fa-rupee-sign"></i> Payment</a>
        </div> <?php 
            $comid=$_SESSION['id']; 
              $compdetails=mysqli_query($conn, "SELECT * from company where companyid='$comid'");
              $c=mysqli_fetch_array($compdetails);
        ?>
        <div style="width:80%">
        <div id="companydetails">
            <h1> <?php echo $c['companyname']; ?></h1><br>
            <h4 style="width:40%"><?php echo $c['addr']; ?></h4>
            <h4><?php echo $c['phone']; ?></h4>
        </div>
        <div class="float-right">
            <tr>
                <td><h3>References: </h3></td>
                
            </tr>
            <tr>
                <td><h3>Name:</td>
                <td><?php echo $c['refname']; ?></h3></td>
            </tr>
            <tr>
                <td><h3>Phone:</td>
                <td><?php echo $c['refphone']; ?></h3></td>

            </tr>
        </div>
        </div>
        

    </div>

       



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
</body>
</html>
<?php }

else{
    array_push($errors, "Please Login to Continue...!");
    header("Location: /2019/login.php");
}
?>