<?php 
    include 'connect.php';
    if(isset($_POST["reg"])){
        $emid=mysqli_real_escape_string($conn, $_POST['EmailID']);
        $Pass=mysqli_real_escape_string($conn, $_POST['Pass']);
        $user=mysqli_real_escape_string($conn, $_POST['refname']);
        $phno=mysqli_real_escape_string($conn, $_POST['Phone']);        
        $rphno=mysqli_real_escape_string($conn, $_POST['refphno']);
        $add=mysqli_real_escape_string($conn, $_POST['Address']);
        $com=mysqli_real_escape_string($conn, $_POST['CompName']);
        if($_POST["Pass"]!=$_POST["CPass"]){
            array_push($errors, "password and confirm password should be same");
        }
        if(count($errors)==0){

            $Pass=md5($Pass);
            $check=mysqli_query($conn,"SELECT * FROM COMPANY WHERE emailid='$emid' OR password='$Pass' ");
            if(mysqli_num_rows($check)>1){
                array_push($errors , "mysqli_num_rows($check)");
                array_push($errors , "Login ID or Password already Exist try any Other");
            }
            else{
                $add=mysqli_query($conn, "INSERT INTO COMPANY VALUES ('0','$emid','$Pass',$phno,'$add','$com','$user',$rphno)");
                if($add){
                    header("Location: /2019/login.php");
                }
                else {
                    array_push($errors , "could not Signe up");
                }
            }
        }
    }
        //login
    if(isset($_POST["log"])){
        $lid=mysqli_real_escape_string($conn, $_POST['LID']);
        $Pass=mysqli_real_escape_string($conn, $_POST['Pass']);
        if (empty($_POST['LID'])) {
            array_push($errors, "enter the login id");
        }
        if (empty($_POST['Pass'])) {
            array_push($errors, "enter the password");
        }
        if(count($errors)==0){
            $Pass=md5($Pass);
            $check=mysqli_query($conn, "SELECT * FROM COMPANY WHERE emailid='$lid' AND password='$Pass'");
            if(mysqli_num_rows($check)<1){
                $check2=mysqli_query($conn, "SELECT * FROM COMPANY WHERE emailid='$lid' ");
                if(mysqli_num_rows($check2)<1){
                    array_push($errors , "Account dosenot exist try to <a href='register.php'>sign UP</a>");
                }else{
                    array_push($errors , "enter the correct password...!");
                }
            }
            else if(mysqli_num_rows($check)==1){
                $ch= mysqli_fetch_array($check);
                session_start();
                $_SESSION["emid"]="$lid";
                $_SESSION["id"]="$ch[companyid]";
                header("Location: /2019/home.php");
            }
        }
        
    }

    //logout
    if(isset($_GET["logout"])){
        
        session_destroy();
        unset($_SESSION["user"]);
        header("Location: /2019");
    }


    if(isset($_POST['addcli'])){
        $cname=$_POST['CompName'];
        $cph=$_POST['Phone'];
        $cadd=$_POST['Address'];
        $cemail=$_POST['EmailID'];
        $rname=$_POST['refname'];
        $rphno=$_POST['refphno'];
        $comid=$_SESSION['id'];
        $check=mysqli_query($conn, "SELECT * FROM CLIENTS WHERE clicmpname=$cname");
        if(mysqli_num_rows($check)>0){
            echo '<script> alert("client name already exists"); </script>';
        }else{
        $addcli=mysqli_query($conn, "INSERT INTO CLIENTS VALUES('$comid', '0', '$cname', $cph, '$cadd', '$cemail','$rname', $rphno)");
        if($addcli){
            echo '<script> alert("Client added Successfully"); </script>';
            header("Location: /2019/client.php");

        }
        else{
            echo '<script> alert("Could not added Client"); </script>';
        }
    }
    }

    if(isset($_POST['Update'])){
        $cid=$_POST['id'];
        $cname=$_POST['CompName'];
        $cph=$_POST['Phone'];
        $cadd=$_POST['Address'];
        $cemail=$_POST['EmailID'];
        $rname=$_POST['refname'];
        $rphno=$_POST['refphno'];
        $comid=$_SESSION['id'];
        $addcli=mysqli_query($conn, "UPDATE `clients` SET `clicmpname`='$cname',`clicmpphno`=$cph,`address`='$cadd',`mailid`='$cemail',`name`='$rname',`phno`=$rphno WHERE `cliid`='$cid' AND `companyid`='$comid'");
        if($addcli){
            echo '<script> alert("Client added Successfully"); </script>';
            header("Location: /2019/client.php");

        }
        else{
            echo '<script> alert("Could not update Client"); </script>';
        }
    }

    if(isset($_POST['addprod'])){
        $type=$_POST['type'];
        $name=$_POST['prodname'];
        $pri=$_POST['price'];
        $taxrt=$_POST['tax'];
        $desc=$_POST['desc'];
        $comid=$_SESSION['id'];
        $addcli=mysqli_query($conn, "INSERT INTO `PRODUCTS` VALUES('$comid', '0', '$type', '$name', $pri, $taxrt,'$desc')");
        if($addcli){
            echo '<script> alert("Client added Successfully"); </script>';
            header("Location: /2019/products.php");
        }
        else{
            echo '<script> alert("Could not added Client"); </script>';
        }
    }

    if(isset($_POST['ediprod'])){
        $pid=$_POST['pid'];
        $type=$_POST['type'];
        $name=$_POST['prodname'];
        $pri=$_POST['price'];
        $taxrt=$_POST['tax'];
        $desc=$_POST['desc'];
        $comid=$_SESSION['id'];
        $addcli=mysqli_query($conn, "UPDATE `PRODUCTS` SET `type`='$type',`name`='$name',`rate`=$pri,`tax`=$taxrt,`descr`='$desc' WHERE `id`='$pid' AND `companyid`='$comid'");
        if($addcli){
            echo '<script> alert("Client added Successfully"); </script>';
            header("Location: /2019/products.php");

        }
        else{
            echo '<script> alert("Could not update product"); </script>';
        }
    }

    if(isset($_POST['delprod'])){
        $pid=$_POST['pid'];
        $comid=$_SESSION['id'];
        $del=mysqli_query($conn, "DELETE FROM `PRODUCTS` WHERE id='$pid' AND `companyid`='$comid'");
        if($del){
            echo '<script> alert("Product Deleted"); </script>';
            header("Location: /2019/products.php");

        }
        else{
            echo '<script> alert("Could not Delete product"); </script>';

        }
    }
   if(isset($_POST['addinvprod'])){
         $id=$_POST['invid'];
        $cliname=$_POST['cliname'];
         $dis=$_POST['dis'];
         $total=$_POST['total'];
         $ftotal=$_POST['ftotal'];
         $adv=$_POST['advance'];
         $bal=$_POST['ballence']; 
        $cliid='';
      
        $r=mysqli_query($conn,"SELECT cliid from clients where clicmpname='$cliname' and companyid='".$_SESSION['id']."'");
        while($row=mysqli_fetch_array($r)){
            $clid=$row['cliid'];
        }
       $compid=$_SESSION['id'];
      
       $insert=mysqli_query($conn,"INSERT INTO invoice values ('$compid','$id','$clid',CURDATE(),$total,$dis, $ftotal,NULL,$bal, $adv  )");
       if($insert){
           echo '<script> alert("invoice added");</script>';
       }else{
        echo '<script> alert("invoice not added");</script>';
       }

       $count=count($_POST['pid']);
       for($i=0;$i<$count;$i++){
        mysqli_query($conn, "INSERT INTO INV_ITM values('".$id."','".$_POST['pid'][$i]."','".$_POST['pname'][$i]."','".$_POST['rate'][$i]."','".$_POST['quantity'][$i]."','".$_POST['tax'][$i]."','".$_POST['amount'][$i]."')");
        }
        if($bal!=$ftotal){
            $payq=mysqli_query($conn, "INSERT INTO PAYMENT values('$id',CURDATE(),$adv,$bal,NULL)");
        }
   }


   if(isset($_POST['addestprod'])){
    $id=$_POST['invid'];
   $cliname=$_POST['cliname'];
    $dis=$_POST['dis'];
    $total=$_POST['total'];
    $ftotal=$_POST['ftotal'];

   $cliid='';
 
   $r=mysqli_query($conn,"SELECT cliid from clients where clicmpname='$cliname'");
   while($row=mysqli_fetch_array($r)){
       $clid=$row['cliid'];
   }
  $compid=$_SESSION['id'];
 
  $insert=mysqli_query($conn,"INSERT INTO estimate values ('$compid','$id','$clid',CURDATE(),$total,$dis, $ftotal,NULL)");
  if($insert){
      echo '<script> alert("estimation added");</script>';
  }else{
   echo '<script> alert("estimation not added");</script>';
  }

  $count=count($_POST['pid']);
  for($i=0;$i<$count;$i++){
   mysqli_query($conn, "INSERT INTO EST_ITM values('".$id."','".$_POST['pid'][$i]."','".$_POST['pname'][$i]."','".$_POST['rate'][$i]."','".$_POST['quantity'][$i]."','".$_POST['tax'][$i]."','".$_POST['amount'][$i]."')");
   }
   
}

    if(isset($_POST['addpay'])){
        $invid=$_POST['invid'];
        $amt=$_POST['amtpay'];
        $bal=0;
        $tak=mysqli_query($conn,"SELECT balance,finalamt,paidamt from invoice where invid=$invid");
        while($row=mysqli_fetch_array($tak)){
            $famt=$row['finalamt'];
            $bal=$row['balance'];
            $paidamt=$row['paidamt'];
        }
        if($bal>=$amt){

        
        $bal=$bal-$amt;
        $paidamt=$famt-$bal;
        $res=mysqli_query($conn,"INSERT INTO payment values($invid,CURDATE(),$amt,$bal,NULL)");
        if($res){
            $rres=mysqli_query($conn,"UPDATE invoice SET balance=$bal where invid=$invid");
            $rres=mysqli_query($conn,"UPDATE invoice SET paidamt=$paidamt where invid=$invid");
            header("location: ./Payment.php");
        }
        else{
            echo "<script>alert('enter a valid invoice id');</script>";
        }
    }
    else {
        echo "<script>alert('enter the correct amount');</script>";
        
    }
    }
?>