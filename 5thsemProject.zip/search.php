<div class="modal-body">
      <form action="" method="POST" style="padding-left:50px;" autocomplete="off">
      <div class="autocomplete" style="width:300px;">
        <input id="myInput" type="text" name="mysearch" placeholder="Search" class="se" required>
      </div> <br> <br>
      <table  class="table tab le-striped table-hover" id="prodtab" style="width:100%">
        <tr>
          <th>Product ID</th>
          <th>Product name</th>
          <th>price</th>
          <th>Quantity</th>
          <th>tax</th>
          <th>Amount</th>
          <th>Options</th>
        </tr>
      </table>
      
      <div class="autocomplete" style="width:300px;">
        <input id="myInput1" type="text" name="mysearch" placeholder="Search" class="se">
      </div>
      <p class="btn btn-primary" id="addprod">Add <i class="fas fa-plus"></i></p>

      <div   style="float:rigth">
        <h6>Total : <input type="number" id="total" style="border: none;outline: none;width:100px;background:none" disabled></h6>
        <h6>Discount : <input type="number" onkeyup="sum()" id="dis" style="border: none;outline: none;width:100px;background:none" value="0"></h6>
        <h6>Final Total : <input type="number" id="tt" style="border: none;outline: none;width:100px;background:none" disabled></h6>
      </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Add" name="addcli">
      </div>