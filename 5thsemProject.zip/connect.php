<?php
    session_start(); 
    $host="localhost";
    $db="project";
    $un="root";
    $pass="!@#password1";
    $errors=array();
    $conn=mysqli_connect($host, $un, $pass, $db);
    // register 
    $emid="";
    $user="";
    $phno="";
    $add="";
    $com="";
    $rphno="";
    
?>