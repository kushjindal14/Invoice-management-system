<?php
include 'connect.php';
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($conn, $_POST["query"]);
	$query = "SELECT * FROM products WHERE name = '$search' AND companyid='".$_SESSION['id']."'";

$result = mysqli_query($conn, $query);
if(mysqli_num_rows($result) > 0)
{
	while($row = mysqli_fetch_array($result))
	{
		$v=$row['rate']+($row['rate'] * ($row['tax']/100))*1;
		$output .= '
			<tr class="invprods" onmouseover="calculate(this)" id='.$row["id"].'>
				<td><input type="hidden"  class="prid" name="pid[]" style="border: none;outline: none;width:100px;background:none"  value="'.$row["id"].'"></td>
				<td><input type="text" class="pname" name="pname[]" style="border: none;outline: none;width:100px;background:none"  value="'.$row["name"].'"></td>
				<td><input type="number" class="rate" name="rate[]" style="border: none;outline: none;width:75px"  value="'.$row["rate"].'"></td>
				<td><input type="number" onkeyup="sum()" class="quantity" name="quantity[]"  style="border: none;outline: none;width:75px" value="1"></td>
				<td><input type="number" onkeyup="sum()" class="tax" name="tax[]" style="border: none;outline: none;width:75px" value="'.$row["tax"].'"></td>
				<td><input type="number" onkeyup="sum()" class="amount" name="amount[]" style="border: none;outline: none;width:75px" value="'.$v.'"></td>
				<td><p name='.$row["id"].' onclick="remove(this)" class="btn btn-danger" id="del">Delete</p></td>
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
}
?>


<!-- $('.amount').each(function(){
	console.log($(this).val());
}); -->