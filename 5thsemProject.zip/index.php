
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HOME</title>
    
    <script defer src="all.min.js"></script>  
    <link rel="stylesheet" href="style.min.css">
    <link rel="stylesheet" href="hom.css">
    <style>
        body{
            background-image: url('indeximg.jpg');
    background-repeat: no-repeat;
    background-size: cover;
    
    }
    h1{
        background-color: rgba(0, 0, 0, 0.274);
    }
        
    </style>
</head>
<body>
	<div class="topline">
        <a href="home.php" class="brand">SSDPP</a>
        <div>
            <a href="register.php">SIGN UP</a>
            <a href="login.php">LOGIN</a>
        </div>
    </div>

        <div style="padding:50px;width:100%;height:100%">
            <h1 style="font-size:5rem;color:black;padding:30px">INVOICE <br> MANAGEMENT <br> SYSTEM</h1>
        </div>
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
</body>
</html>