
<?php  
    if(isset($_POST['add'])){
        $invid=$_POST['inid'];
        $pid=$_POST['prodid'];
        $pname=$_POST['prodname'];
        $price=$_POST['prodrate'];
        $quantity=$_POST['prodquantity'];
        $tax=$_POST['prodtax'];
        $amt=$_POST['prodamt'];
        mysqi_query($conn,"INSERT INTO inv_itm values('$invid','$pid','$pname','$price','$quantity','$tax','$amt')");
    }
?> 