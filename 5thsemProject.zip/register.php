<?php include "phpscripts.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="all.min.js"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.2/js/all.js"></script>  
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style.min.css">
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    
    <div class="rcontainer">
        <h1 id="lo"><i class="fas fa-user-plus"></i></h1>
            <?php include "error.php"; ?>

            <form action="" method="post" class="fform" autocomplete="off" >
            <input class="in"  type="text" name="CompName"  required placeholder="Company Name" value="<?php echo $com;?>">
            <input class="in"  type="tel" name="Phone" required placeholder="Phone Number" value="<?php echo $phno;?>">
            <input class="in" id="sp" style="width:95.5% "  type="text" name="Address"  required placeholder="Address" value="<?php echo $add;?>"><br>
            <input class="in"  type="email" name="EmailID"  required placeholder="Email ID" value="<?php echo $emid;?>">
            <input class="in"  type="password" name="Pass"  required placeholder="Password" >
            <input  class="in" type="password" name="CPass"  required placeholder="Confirm Password"><br><br>
            <label class="p" for="Referance person">Reference person : </label><br>
            <input class="in" type="text" name="refname" required placeholder="Name" <?php echo $user;?>>
            <input class="in" type="tel" name="refphno" required placeholder="Phone Number" <?php echo $rphno;?>>
            <div class="rg">
            <p class="lin">Have an account already?<a href="login.php">Login</a></p>
            <input  type="submit" name="reg" value="Sign UP" class="btn btn-primary" id="reg">
            </div>
            
          </form>
        </div>
    </div>




    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
</body>
</html>