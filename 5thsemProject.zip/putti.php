<?php 
     $host="localhost";
     $db="login";
     $un="root";
     $pass="!@#password1";
     $conn=mysqli_connect($host, $un, $pass, $db);
     if($conn){
         echo 'connected';
     }
     else echo 'not connected';
     
    if(isset($_POST['reg'])){
       $username=$_POST['username'];
       $pass=$_POST['password'];
   
        $result=mysqli_query($conn, "INSERT INTO `login` (`username`, `pasasword`) VALUES ('$username', '$pass')");
           if($result){
               echo '<br>'.'inserted';
           } 
           else echo 'not inserted';
        
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <input type="text" name="username" id="">
        <input type="password" name="password" id="">
        <input type="submit" name="reg" value="reg">
    </form>
</body>
</html>