<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="ajjs"></script>
	<script src="bootstrap.min.js"></script>
    <script  src="all.min.js"></script>  
    <link rel="stylesheet" href="style.min.css">
    <link rel="stylesheet" href="homm.css">
    <script src="jquery.js"></script>`
</head>
<body>
<table class="table table-bordered" id="stock" >
    <thead>
    <tr>
        <td>Sr no.</td>
        <td>Product Name</td>
        <td>Description</td>
        <td>Qty</td>
        <td>Unit</td>
        <td>Rate</td>
        <td>Tax</td>
        <td>Dis</td>
        <td>Total</td>
        <td><input type="button" name="add" id="add" value="+" class="btn btn-warning" /></td>
    </tr>
    </thead>
    <tbody class="details">
    <tr>
        <td class="no">1</td>
        <td><input type="text" name="items[]" id="items_1" class="form-control items"  autocomplete="off" /></td>
        <td><textarea name="size[]" id="size_1" class="form-control size" autocomplete="off"></textarea></td>
        <td><input type="text" name="qty[]" id="qty_1" class="form-control qty" autocomplete="off"/></td>
        <td><input type="text" name="unit[]" id="unit_1" class="form-control unit" autocomplete="off"/></td>
        <td><input type="text" name="price[]" id="price_1" class="form-control price" autocomplete="off"/></td>
        <td><input type="text" name="tax[]" id="tax_1" class="form-control tax"  autocomplete="off" /></td>
        <td><input type="text" name="dis[]" id="dis_1" class="form-control dis" autocomplete="off" /></td>
        <td><input type="text" name="stkamt[]" id="amt" class="form-control amt" autocomplete="off" /></td>
        <td><button class="btn btn-danger remove">X</button></td>
    </tr>
    </tbody>
    <tfoot></tfoot>
</table>
<script>
$(function(){
  $('#add').click(function(){
    addnewrow();
  });
});

function addnewrow()
{
    var n = ($('.details tr').length - 0) + 1;
    var tr = '<tr>'+
        '<td class="no">' + n + '</td>' +
        '<td><input type="text" name="items[]" id="items_' + n + '" class="form-control items"  autocomplete="off" /></td>' +
        '<td><textarea name="size[]" id="size_' + n + '" class="form-control size" autocomplete="off"></textarea></td>' +
        '<td><input type="text" name="qty[]" id="qty_' + n + '" class="form-control qty" autocomplete="off"/></td>' +
        '<td><input type="text" name="unit[]" id="unit_' + n + '" class="form-control unit" autocomplete="off"/></td>' +
        '<td><input type="text" name="price[]" id="price_' + n + '" class="form-control price" autocomplete="off"/></td>' +
        '<td><input type="text" name="tax[]" id="tax_' + n + '" class="form-control tax"  autocomplete="off" /></td>' +
        '<td><input type="text" name="dis[]" id="dis_' + n + '" class="form-control dis" autocomplete="off" /></td>' +
        '<td><input type="text" name="stkamt[]" id="amt_' + n + '" class="form-control amt" autocomplete="off" /></td>' +
        '<td><button class="btn btn-danger remove">X</button></td>' +
        '</tr>';
    $('.details').append(tr);
};

$('body').delegate('.items', 'blur', function(e) {
    checkitems(e.currentTarget.id.split('_')[1]);   // e.currentTarget.id.split('_')[1] - Target element ID
});

function checkitems(targetID)
{
    var items = $('#items_' + targetID).val();
    if (items != "") {
      $.ajax({
        type: 'post',
        url: 'itemcheck.php', 
        data: {key: items},
        dataType: 'json',
        success: function(data) {   
        if (data) {
            var tr = $(this).closest('tr'); // here is the code for retrieving the values. i think here i need to make some changes     
            $('#price_' + targetID).val(data.rate);
            $('#size_' + targetID).val(data.des);
            $('#qty_' + targetID).val(data.qty);
            $('#unit_' + targetID).val(data.unit);
        } else {
           $('#myitemmodal').modal("show");
         }
       }
      });
    }
};
</script>
</body>
</html>