<?php if(count($errors)>0): ?>
    <div class="error">
        <?php foreach($errors as $er): ?>
            <p><?php echo $er; ?></p>
        <?php endforeach ?>
    </div>
<?php endif ?>