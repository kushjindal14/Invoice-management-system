<?php include "phpscripts.php";
        $res="";
        $var=""; 
         $res=mysqli_query($conn, "SELECT clicmpname FROM CLIENTS WHERE companyid='".$_SESSION['id']."'") ;
         $ar=[];
         $arr=[];
        while($array=mysqli_fetch_array($res)){ 
            # code...
            array_push($ar, $array['clicmpname']);
        } 
        $res=mysqli_query($conn, "SELECT name FROM products WHERE companyid='".$_SESSION['id']."'") ;

        while($array=mysqli_fetch_array($res)){
          array_push($arr, $array['name']);
        }
        $invfetch=mysqli_query($conn,"SELECT * FROM INVOICE ");
        $invid=1 + mysqli_num_rows($invfetch);
    if(isset($_SESSION['id'])){  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HOME</title>
    <script src="ajjs"></script>
  <script src="bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script  src="all.min.js"></script>  
    <link rel="stylesheet" href="style.min.css">
    <link rel="stylesheet" href="hom.css">
    <script src="jquery.js"></script>
</head>
<body>
	<div class="topline">
        <a href="home.php" class="brand">SSDPP</a>
        <a href="phpscripts.php?logout=1">LOGOUT</a>
    </div>
    <div class="contents">
        <div class="varticalnav">
            <a href="home.php"><i class="fas fa-home"></i> Home</a><b><br><br><br><br></b>
            <a href="products.php"><i class="fab fa-product-hunt"></i></i> Products</a>
            <a href="invoice.php" id="active"><i class="fas fa-file-invoice"></i> Invoice</a>
            <a href="client.php"><i class="far fa-user"></i> Clients</a>
            <a href="estimate.php"><i class="far fa-file-alt"></i> Estimate</a>
            <a href="Payment.php"><i class="fas fa-rupee-sign"></i> Payment</a>
        </div>
        <div class="realcon">
            <div class="fstln">
                <div style="padding-right:20px;margin-left:auto">
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addinv"><i class="fas fa-plus"></i> Add</button>                        </div>
            </div>
            <hr class="style-one">
            <div style="margin: 0 20px;">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						            <th>SL NO</th>
                        <th>DATE</th>
                        <th>INVOICE ID</th>
                        <th>CLIENT NAME</th>
                        <th>AMOUNT</th>
                        <th>BALANCE</th>
                        <th>STATUS</th>
                        <th>VIEW</th>
                    </tr>
                </thead>

				<tbody>
				
				<?php
                $comid=$_SESSION['id'];
				$result = mysqli_query($conn,"SELECT * FROM INVOICE WHERE companyid='$comid'");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
            $cliid=$row['clitid'];
            $cliname=mysqli_query($conn, "SELECT clicmpname from clients where companyid='$comid' and cliid='$cliid' ");
            $cliname=mysqli_fetch_array($cliname);                     
				?>
				<tr id="<?php echo $row["invid"]; ?>">
					<td><?php echo $i; ?></td>
					<td><?php echo $row["invdate"]; ?></td> 
					<td><?php echo $row["invid"]; ?></td> 

                    <?php ?>
					<td><?php echo $cliname['clicmpname']; ?></td>
					<td><?php echo $row["amount"]; ?></td>
					<td><?php echo $row["balance"]; ?></td>
					<td><?php if($row['balance']!=0){echo 'Pending';} else{echo 'paid';} ?></td>
          <td>
          <form action="invoicetemp.php" target="blank" method="post">
            <input type="hidden" name="invid" value="<?php echo $row["invid"]; ?>">
            <input type="submit" value="view">
          </form>
          </td>
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
            </div>
        </div>
    </div>
    <!-- Add a invoice model -->
    <div onmouseover="sum()" class="modal fade" id="addinv" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" id="dilog" role="document">
    <div class="modal-content" id="modcont">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Invoice</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="" method="POST" style="padding-left:50px;" autocomplete="off">
      <input type="hidden" name="invid" value=<?php echo $invid; ?> id="invid">
      <div class="autocomplete" style="width:300px;">
        <input id="myInput" type="text" name="cliname" placeholder="Search" class="se clise" required>
      </div> <br> <br>
      <div class="ui search">
  <div class="ui icon input">
    <input class="prompt" type="text" placeholder="Search countries...">
    <i class="search icon"></i>
  </div>
  <div class="results"></div>
</div>
<script>
  $('.ui.search')
  .search({
    source: content
  })
;

var content = [
  { title: 'Andorra' },
  { title: 'United Arab Emirates' },
  { title: 'Afghanistan' },
  { title: 'Antigua' },
  { title: 'Anguilla' },
  { title: 'Albania' },
  { title: 'Armenia' },
  { title: 'Netherlands Antilles' },
  { title: 'Angola' },
  { title: 'Argentina' },
  { title: 'American Samoa' },
  { title: 'Austria' },
  { title: 'Australia' },
  { title: 'Aruba' },
  { title: 'Aland Islands' },
  { title: 'Azerbaijan' },
  { title: 'Bosnia' },
  { title: 'Barbados' },
  { title: 'Bangladesh' },
  { title: 'Belgium' },
  { title: 'Burkina Faso' },
  { title: 'Bulgaria' },
  { title: 'Bahrain' },
  { title: 'Burundi' }
  // etc
];
</script>
      <table  class="table tab le-striped table-hover" id="prodtab" style="width:100%">
        <tr>
          <th></th>
          <th>Product name</th>
          <th>price</th>
          <th>Quantity</th>
          <th>tax</th>
          <th>Amount</th>
          <th>Options</th>
        </tr>
      </table>

      <link rel="stylesheet" type="text/css" href="semantic/dist/semantic.min.css">
<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
<script src="semantic/dist/semantic.min.js"></script>

      <div class="autocomplete" style="width:300px;">
        <input id="myInput1" type="text" name="mysearch" placeholder="Search" class="se">
      </div>
      <p class="btn btn-primary" id="addprod">Add <i class="fas fa-plus"></i></p>

      <div style="margin-left:70%;display:flex;">
      <div>
      <h6>Total : </h6>
        <h6>Discount : 
        <h6>Final Total : </h6>
        <h6>Advanve: </h6>
        <h6>Balance: </h6>
      </div>
        <div style="padding-left:20px" >
        <input type="number" name="total" id="total" style="border: none;outline: none;width:100px;background:none;padding-left 2px;"> <br>
        <input type="number" onkeyup="sum()"   name="dis" id="dis" style="border: none;outline: none;width:100px;background:none;padding-left 2px;" value=0> <br>
        <input type="number" name="ftotal" id="tt" style="border: none;outline: none;width:100px;background:none;padding-left 2px;" > <br>
        <input type="number" onkeyup="sum()" value=0 name="advance" id="adv" style="border: none;outline: none;width:100px;background:none;padding-left 2px;" > <br>
        <input type="number" name="ballence" id="ball" style="border: none;outline: none;width:100px;background:none;padding-left 2px;" >
        </div>
      </div>

      </div>  
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Add" id="add" name="addinvprod" >
      </div>
      </form>
    </div>
  </div>
</div>
<!-- <input type="number" name="total" id="total" style="border: none;outline: none;width:100px;background:none" disabled>
<input type="number" name="dis"  onkeyup="sum()" id="dis" style="border: none;outline: none;width:100px;background:none" value="0">
<input type="number" name="ftotal"  id="tt" style="border: none;outline: none;width:100px;background:none" disabled> -->

    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>



        <script>



  $(document).ready(function(){
	load_data();
 
	function load_data(query)
	{
		$.ajax({
			url:"searchphp.php",
			method:"post",
			data:{query:query},
			success:function(data)
			{       $('#myInput1').val('');

				$('#prodtab').append(data);
        
			}
		});
	}
	


	$('#addprod').click(function(){
		var search = $('#myInput1').val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
			load_data();		

		}
	});
});


// $('#add').click(function(){
//   $('.invprods').each(function(){
//     var prid=$(this).find('.prid').html();
//     var pname=$(this).find('.pname').html();
//     var rate=$(this).find('.rate').val();
//     var q=$(this).find('.quantity').val();
//     var tax=$(this).find('.tax').val();
//     var amt=$(this).find('.amount').val();
//     var addp='add';
//     var invid=$(this).find('#invid').val();
//     $.ajax({
// 			url:"addprod.php",
// 			method:"post",
// 			data:{
//         inid:invid,
//         add:addp,
//         prodid:prid,
//         prodname:pname,
//         prorate:rate,
//         proquantity:q,
//         protax:tax,
//         proamt:amt
//       }
// 		});
//   });
// });

function sum(){
  $sum=0;
  $('.amount').each(function(){
    $sum+=parseInt(($(this).val()));
  });
  
  $('#total').val($sum);
  $dis=$('#dis').val();
  $tt=$sum-$dis;
  $('#tt').val($tt);
  $adv=$('#adv').val();
  if ($adv>$tt) {
    $adv=$('#adv').val(0);
    $adv=$('#adv').val();

  }

  $bal=$tt-$adv;
  $('#ball').val($bal);
}



function remove(i)
{
	$id='#'+$(i).attr('name');
		$($id).remove();
}


////////////
function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
          b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = this.getElementsByTagName("input")[0].value;
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
        x[i].parentNode.removeChild(x[i]);
      }
    }
  }
  /*execute a function when someone clicks in the document:*/
  document.addEventListener("click", function (e) {
      closeAllLists(e.target);
  });
}

/*An array containing all the country names in the world:*/

var names =<?php echo json_encode($arr); ?>;
/*initiate the autocomplete function on the "myInput" element, and pass along the countries array as possible autocomplete values:*/
autocomplete(document.getElementById("myInput1"), names);

  // $(document).ready(function(){
  //     $('#checkdetail').click(function(e){
  //       e.preventDefault();
  //       $.ajax({
  //         method: 'POST',
  //         url: 'phpscripts.php',
  //         data: $('#myInput').val(),
  //         dataType: "text",
  //         success: function(response){
  //           $('#details').text(response);
  //         }
  //       })
  //     });
  // });

// $('tr').change(function(){

////////////////////////////


function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
          b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = this.getElementsByTagName("input")[0].value;
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
        x[i].parentNode.removeChild(x[i]);
      }
    }
  }
  /*execute a function when someone clicks in the document:*/
  document.addEventListener("click", function (e) {
      closeAllLists(e.target);
  });
}

/*An array containing all the country names in the world:*/

var names =<?php echo json_encode($ar); ?>;
/*initiate the autocomplete function on the "myInput" element, and pass along the countries array as possible autocomplete values:*/
autocomplete(document.getElementById("myInput"), names);

  // $(document).ready(function(){
  //     $('#checkdetail').click(function(e){
  //       e.preventDefault();
  //       $.ajax({
  //         method: 'POST',
  //         url: 'phpscripts.php',
  //         data: $('#myInput').val(),
  //         dataType: "text",
  //         success: function(response){
  //           $('#details').text(response);
  //         }
  //       })
  //     });
  // });

// $('tr').change(function(){
//   console.log('changed');
// });
//  $('tr').each(function(){
//    $(this).find('.rate').change(function(){
//      console.log($(this).val());
//    }); 
//    $(this).find('.quantity').change(function(){
//      console.log($(this).val());
//    });
//    $(this).find('.tax').change(function(){
//      console.log($(this).val());
//    });

//  });

  $a=0;
  function calculate(i){
    $(i).find('.rate, .quantity, .tax, .amount').keyup(function(){
      $a=0;
      $r=$(i).find('.rate').val();
      $q=$(i).find('.quantity').val();
      $t=$(i).find('.tax').val();
      $t=$t/100;
      $e=$r*$q;
      $p=$e*$t;
      $a=$p+$e;
      $(i).find('.amount').val($a);
      $(i).off();
      sum();
    });
  };



</script>
<script>
  // $('#cal').change(function(){
  //  console.log( $(this).find('.rate').val());
  // });
</script>

</body>
</html>
<?php }

else{
    array_push($errors, "Please Login to Continue...!");
    header("Location: /2019/login.php");
}
?>