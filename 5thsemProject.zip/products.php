<?php  
    include 'phpscripts.php';
    if(isset($_SESSION['id'])){  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HOME</title>
    <script src="bootstrap.min.js"></script>
    <script defer src="all.min.js"></script>  
    <link rel="stylesheet" href="style.min.css">
    <link rel="stylesheet" href="hom.css">
    <script src="ajjs"></script>

</head>
<body>
	<div class="topline">
        <a href="home.php" class="brand">SSDPP</a>
        <a href="phpscripts.php?logout=1">LOGOUT</a>
    </div>
    <div class="contents">
        <div class="varticalnav">
            <a href="home.php"><i class="fas fa-home"></i> Home</a><b><br><br><br><br></b>
            <a href="products.php" id="active"><i class="fab fa-product-hunt"></i></i> Products</a>
            <a href="invoice.php" ><i class="fas fa-file-invoice"></i> Invoice</a>
            <a href="client.php"><i class="far fa-user"></i> Clients</a>
            <a href="estimate.php"><i class="far fa-file-alt"></i> Estimate</a>
            <a href="Payment.php"><i class="fas fa-rupee-sign"></i> Payment</a>
        </div>
        <div class="realcon">
            <div class="fstln">
                <form>
                </form>
                <div style="padding-right:15px;">
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addprod"><i class="fas fa-plus"></i> Add</button> 
                </div>
            </div>
            <hr class="style-one">
            <div style="margin: 0 20px;">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
						<th>SL NO</th>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Name</th>
                        <th>Price</th>
						<th>Tax</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
				<tbody>
				
				<?php
                $id=$_SESSION['id'];
				$result = mysqli_query($conn,"CALL retrive_products('$id')");
                    $i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["id"]; ?>">
					<td><?php echo $i; ?></td>
					<td><?php echo $row["id"]; ?></td>
					<td><?php echo $row["type"]; ?></td>
					<td><?php echo $row["name"]; ?></td>
					<td><?php echo $row["rate"]; ?></td>
					<td><?php echo $row["tax"]; ?>%</td>
					<td>
                    <a href="#editprod<?php echo $row["id"]; ?>" data-toggle="modal">
                        <i class="fas fa-user-edit" data-toggle="tooltip" title="Edit"></i>
                    </a>
                    <a href="#dispproddetails<?php echo $row["id"]; ?>" style="color:#077BFF;padding-left:15px;" data-toggle="modal">
                        <i class="fas fa-info"></i>
                    </a>
						<a href="#deleteprod<?php echo $row["id"]; ?>" class="delete" data-id="<?php echo $row["id"]; ?>" style="color:#077BFF;padding-left:15px;" data-toggle="modal"><i class="far fa-trash-alt"></i></a>
                    </td>
                    <!-- model to display product details -->
                    <div class="modal fade" id="dispproddetails<?php echo $row["id"]; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Product details</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    </div>
                                    <div class="modal-body">
                                    <div class="disp" style="display: flex;justify-content: space-evenly;">
                                    <div >
                                        <p>id: </p>
                                        <p>Name: </p>
                                        <p>Price: </p>
                                        <p>Tax: </p>
                                        <p>Description: </p>
                                    </div>
                                    <div>
                                        <p><?php echo $row["id"]; ?></p>
                                        <p><?php echo $row["name"]; ?></p>
                                        <p><?php echo $row["rate"]; ?></p>
                                        <p><?php echo $row["tax"]; ?>%</p>
                                        <p><?php echo $row["descr"]; ?></p>
                                    </div>
                                    </div>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <a href="#editprod<?php echo $row["id"]; ?>" class="btn btn-primary"  style="color:white" data-toggle="modal">
                                        <i class="fas fa-user-edit" data-toggle="tooltip" title="Edit"></i>
                                    </a>
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!-- model to edit the Product -->
                    <div class="modal fade" id="editprod<?php echo $row["id"]; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Product</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="" method="POST" class="adcli">
                                <div class="adcli">
                                        <div class="adprod">
                                        <h6><input type="radio" name="type" id="" value="Goods" <?php if($row['type']=='Goods')echo "checked";?>>Goods</h6><br>
                                        <h6 style="padding:0 15px;"><input type="radio" name="type" id="" value="Service" <?php if($row['type']=='Service') echo "checked";?>>Services</h6><br> 
                                        </div>
                                        
                                    <input type="hidden" name="pid" value="<?php echo $row["id"]; ?>">
                                    <input class="in"  type="text" name="prodname"  required placeholder="Product Name" value="<?php echo $row["name"]; ?>"><br>
                                    <input class="in"  type="number" name="price" required placeholder="Price" value="<?php echo $row["rate"]; ?>"><br>
                                    <input class="in" type="number" name="tax" id="" placeholder="Tax rate" value="<?php echo $row["tax"]; ?>">            
                                    <input class="in" style="margin-top:20px;" type="text" name="desc" id="" value="<?php echo $row["descr"]; ?>" placeholder="description of the produce" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <input type="submit" class="btn btn-primary" value="Update" name="ediprod">
                            </div>
                            </form>
                            </div>
                        </div>
                    </div>
                    <!-- model to delete a product -->
                    <div class="modal fade" id="deleteprod<?php echo $row["id"]; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Delete Product</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="" method="POST" class="adcli">
                                    <input type="hidden" name="pid" value="<?php echo $row["id"]; ?>">
                                    <h2>Name: <?php echo $row["name"]; ?></h2><br>
                                    <h3>After deleting the data can not be retrived</h3>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <input type="submit" class="btn btn-primary" value="Delete" name="delprod">
                            </div>
                            </form>
                            </div>
                        </div>
                    </div>
                    
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
            </div>
        </div>
    </div>
<!-- model to add products -->
    <div class="modal fade" id="addprod" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST" class="adcli">
                <div class="adprod">
                <h6><input type="radio" name="type" id="" value="Goods" required>Goods</h6><br>
                <h6 style="padding-left:15px;"><input type="radio" name="type" id="" value="Service" required>Services</h6><br> 
                </div>
                
            <input class="in"  type="text" name="prodname"  required placeholder="Product Name"><br>
            <input class="in"  type="number" name="price" required placeholder="Price"><br>
            <input class="in" type="number" name="tax" id="" required placeholder="Tax rate without %" value="">            
            <input class="in" style="margin-top:20px;" type="text" name="desc" id="" placeholder="description of the produce">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Add" name="addprod">
      </div>
      </form>
    </div>
  </div>
</div>


    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
</body>
</html>
<?php }

else{
    array_push($errors, "Please Login to Continue...!");
    header("Location: /2019/login.php");
}
?>