<?php 
include 'phpscripts.php';
    if(isset($_SESSION['id'])){  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HOME</title>
    <style>
        input{
            border:1px solid black;
            outline:none;
            border-radius:5px;
            padding:2px 0 2px 20px;
        }
    </style>
    <script defer src="all.min.js"></script>  
    <link rel="stylesheet" href="style.min.css">
    <link rel="stylesheet" href="hom.css">
</head>
<body>
	<div class="topline">
        <a href="home.php" class="brand">SSDPP</a>
        <a href="phpscripts.php?logout=1">LOGOUT</a>
    </div>
    <div class="contents">
        <div class="varticalnav">
            <a href="home.php"><i class="fas fa-home"></i> Home</a><b><br><br><br><br></b>
            <a href="products.php"><i class="fab fa-product-hunt"></i></i> Products</a>
            <a href="invoice.php"><i class="fas fa-file-invoice"></i> Invoice</a>
            <a href="client.php"><i class="far fa-user"></i> Clients</a>
            <a href="estimate.php"><i class="far fa-file-alt"></i> Estimate</a>
            <a href="payment.php" id="active"><i class="fas fa-rupee-sign"></i> Payment</a>
        </div>
        <div class="realcon">
            <div class="fstln">
                
                <div style="padding-right:20px;margin-left:auto">
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addpay">Record Payment</button>                        
                    </div>
            </div>
            <hr class="style-one">
            <div style="margin: 0 20px;">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>PAYMENT ID</th>
                        <th>DATE</th>
                        <th>INVOICE ID</th>
                        <th>AMOUNT</th>
                        <th>BALANCE</th>
                    </tr>
                </thead>

				<tbody>
				
				<?php
                $comid=$_SESSION['id'];
				$result = mysqli_query($conn,"SELECT * FROM payment");
					$i=1;
					while($row = mysqli_fetch_array($result)) {
				?>
				<tr id="<?php echo $row["PAYMENT_ID"]; ?>">
					<td><?php echo $row["PAYMENT_ID"]; ?></td> 
					<td><?php echo $row["paydate"]; ?></td> 
					<td><?php echo $row["invid"]; ?></td> 
					<td><?php echo $row["amount"]; ?></td> 
					<td><?php echo $row['ballance']; ?></td>
				</tr>
				<?php
				$i++;
				}
				?>
				</tbody>
			</table>
            </div>
        </div>  
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>






        <div onmouseover="sum()" class="modal fade" id="addpay" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" id="dilog" style="width:700px" role="document">
    <div class="modal-content" id="modcont">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Invoice</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="" method="POST" style="padding-left:50px;" autocomplete="off">
                <div style="display:flex;justify-content:space between">
                    <div>
                    <h4>Invoice ID:</h4>
                    <h4>Amount :</h4>
                    </div>
                    <div style="padding-left:50px">
                        <h4><input style="font-size:20px;" type="number" name="invid" id="invid"></h4>
                        <h4><input required style="font-size:20px;" type="number" name="amtpay" id="amtpay"> </h4>                         
                    </div>
                </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Add" id="add" name="addpay">
      </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>
<script>

</script>

<?php }

else{
    array_push($errors, "Please Login to Continue...!");
    header("Location: /2019/login.php");
}
?>